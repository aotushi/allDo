export const useUser = defineStore('user', {
  state: () => ({
    userInfo: null,
  }),
})
