<template>
  <div>
    <NDialogProvider>
      <NMessageProvider>
        <NuxtLayout>
          <NuxtPage></NuxtPage>
        </NuxtLayout>
      </NMessageProvider>
    </NDialogProvider>
  </div>
</template>

<style>
a {
  color: white;
  text-decoration: none;
}
</style>
