<template>
  <div class="mt-auto bg-dark-400 text-light-500">
    <div class="flex items-center justify-center pb-1 pt-2">
    </div>
    <div class="mx-auto border-solid border-0 border-t border-gray-700 text-center py-4">
      Copyright© 2023 by YCXT
    </div>
  </div>
</template>
